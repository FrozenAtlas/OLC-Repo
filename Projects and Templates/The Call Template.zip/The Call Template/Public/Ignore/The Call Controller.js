// -----JS CODE-----
// @input Asset.Texture video
// @input Component.AudioComponent ringtone
// @input string username
// @input float callDuration
// @input bool advanced
// @input Component.Text profile {"showIf":"advanced"}
// @input SceneObject tweens {"showIf":"advanced"}
var count = 0;
var videoPlaying = false;
var tweening = false;

print("Welcome to The Call! Using this template, you can create your own custom fake video chat lens!")
print("Step 1: Create your own fake video, and import it into Lens Studio. Make sure it is 720x1280 in resolution, an MP4 file, and is under 3.5MB. To compress and scale your video, you can use a website like www.videosmaller.com!");
print("Step 2: Select your fake video, and make sure 'Autoplay' is unchecked. Add your fake video to the 'Video' object in the Scene Panel.");
print("Step 3: Import your own custom ringtone MP3 file (try to keep under 5 seconds), and add it to the 'Ringtone' Object in the Scene Panel");
print("Step 4: Import your own circular icon, and add it to the 'Profile Icon' object in the Scene Panel");
print("Step 5: Select 'The Call Controller' in the Scene Panel. In the Inspector Panel, add your fake video to the area labeled 'Video'. Change the 'Username' to your own, and change the 'Call Duration' to the length of your fake video.")
print("Step 6: Test out your video, and enjoy! If you have any questions, feel free to email me at kargraphical@gmail.com with the subject 'The Call Help'");

function onTapped(eventData)
{
    if (!videoPlaying && !tweening)
    {
        count++;
    }
    
    if (count == 1 && !videoPlaying && !tweening)
    {
        var delayedEvent =  script.createEvent("DelayedCallbackEvent");
        delayedEvent.bind(function(eventData)
        {
            tweening = false;
        });
        delayedEvent.reset(1.5);  
        
        tweening = true;
        
        if (script.ringtone)
        {
        script.ringtone.play(-1);
        }
        
        script.profile.text = script.username
        global.tweenManager.startTween(script.tweens, "incoming");
    }
    
    if (count == 2 && !videoPlaying && !tweening)
    {
        var delayedEvent =  script.createEvent("DelayedCallbackEvent");
        delayedEvent.bind(function(eventData)
        {
            script.video.control.stop();
            global.tweenManager.startTween(script.tweens, "end");
            count = 0;
            videoPlaying = false;
        });
        delayedEvent.reset(script.callDuration);        
        
        videoPlaying = true;
        script.ringtone.stop(true);
        global.tweenManager.startTween(script.tweens, "answer");
        script.video.control.play(1);
        count = -1;
    }
}

var event = script.createEvent("TapEvent");
event.bind(onTapped);