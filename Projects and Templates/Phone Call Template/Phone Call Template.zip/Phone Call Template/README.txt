INSTRUCTIONS

Step 1. Donwload the project folder 
Step 2. Open the project. Notice all the scene objects labeled �[EDIT ME]� and the Resources labeled �[REPLACE ME]�. You will be changing these to add your own profile photo, username and video.

Step 3. In the Orthographic Camera, find the �Username[EDIT ME]� scene object. Click this and look in the �Inspector� to the left of the preview person. Change the text to your name.

Step 4. Create your own profile photo inside a circle as a transparent PNG file. Make sure it is compressed and small enough so it is under 50KB. Add this photo to your project, and change the �Profile Photo[EDIT ME]� scene object to that profile photo texture.

Step 5. Create your own fake video to replace the adorable dog currently in the project. NOTE: your video will need to be under 3.5MB, so try running it through www.videosmaller.com several times. I scaled the video width to 640 and that helped a lot. Add your video to the project, and add it to the �Fake Video[EDIT ME]� Scene object.

Step 6. Click �The Call[EDIT ME]� Script scene object. In the inspector, add your fake video where it says �The Call�. Change the Video length to match your videos length so it will restart the lens when the video is done.

Step 7. Have a bunch of fake virtual phone calls with people around the world and enjoy!

Made by Ben