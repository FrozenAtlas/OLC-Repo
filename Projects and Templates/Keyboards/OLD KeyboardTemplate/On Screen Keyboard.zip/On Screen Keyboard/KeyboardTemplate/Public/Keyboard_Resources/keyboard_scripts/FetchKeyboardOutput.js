// Max van Leeuwen - maxvanleeuwen.com
// snap, insta, twitter @ maxeflats

//@input Component.Label LabelForKeyboard


// -> set to Frame Updated and select the right label in your scene


script.LabelForKeyboard.text = global.KeyboardOut;