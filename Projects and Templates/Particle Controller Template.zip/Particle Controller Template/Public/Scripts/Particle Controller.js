// ----Created By Ben Knutson 8/3/2019----
// ---------www.kargraphics.com-----------
// @input Asset.Material[] particles
// @input float particleIntensity = 0.5;

print("Welcome to the Particle Controller! In order for the script to work, you need to make sure 'External Time' is checked in each Particle Material you add to this script. Adjust the Particle Intenisty to change how fast the particles move! If you have any questions, contact me through www.kargraphics.com");
print("Happy Creating!");

// Stops particles by default
var playingParticles = false;

// If you'd like to change the trigger event to something else, just copy the inner contents of each mouth event, and paste them inside the event you would like to add!
function onMouthOpened(time)
{
 global.controlTime = getTime();
 playingParticles = true;
}
var mouthOpenedEvent = script.createEvent("MouthOpenedEvent");
mouthOpenedEvent.bind(onMouthOpened);

function onMouthClosed(time)
{
 playingParticles = false;
}
var mouthClosedEvent = script.createEvent("MouthClosedEvent");
mouthClosedEvent.bind(onMouthClosed);


function onUpdate (time)
{
    if (playingParticles) 
    {
        global.animTime = global.controlTime - getTime();
        var positiveTime = -animTime * script.particleIntensity;

        for (var i = 0; i < script.particles.length; i++)
        {
            script.particles[i].mainPass.externalTimeInput = positiveTime; 
        }
    }
    else 
    {
        global.animTime = global.controlTime - getTime();
        var positiveTime = -animTime * 0;

        for (var i = 0; i < script.particles.length; i++)
        {
            script.particles[i].mainPass.externalTimeInput = positiveTime; 
        }
    }

}
var updateEvent = script.createEvent("UpdateEvent");
updateEvent.bind(onUpdate);