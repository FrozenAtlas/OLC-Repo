// -----JS CODE-----
print("Welcome to the Skeletal Mask Template! When you add your own effects, make sure they are in the 'Effects Camera' and are set to the yellow Effects layer! You can also edit the PNG Textures for the skeletal mask to more suit your needs! If you have any questions, feel free to reach out to the creator (Ben) at kargraphical@gmail.com.");
print("Happy Creating!");
