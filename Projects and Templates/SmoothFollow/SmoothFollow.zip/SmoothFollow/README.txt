This is a project that Amir at the Lens Studio team sent me. 
This will take any object you want and make it move towards your face. 
You can edit the offset and the speed to make it just how you want it! 
All I did was email OLCsupport asking if this was possible, and they sent me this back, they are a great resource!

-Ben