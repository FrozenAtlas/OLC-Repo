Blink trigger project
Made by Sprofane (OLC) Sprofane#4739