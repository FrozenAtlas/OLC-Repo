// -----JS CODE-----
global.play = false;

function onTapped(eventData)
{
    if (!global.play)
    {
        global.play = true;
        global.start = true;
        print("Start Game");       
    }
}

var event = script.createEvent("TouchStartEvent");
event.bind(onTapped);
