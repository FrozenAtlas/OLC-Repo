// -----JS CODE-----
// @input Component.Camera cam
// @ui {"widget":"group_start", "label":"Spawning Parameters"}
// @input SceneObject parentObject
// @input float spawnInterval = 10
// @input float minDistance = 500
// @input float maxDistance = 1000
// @input float maxHeight = 300
// @input float minSize = 35
// @input float maxSize = 50
// @input Asset.ObjectPrefab[] asteroid
// @input Asset.ObjectPrefab laser
// @ui {"widget":"group_end"}
// @ui {"widget":"group_start", "label":"Game Over"}
// @input float minGameOverDistance = 50
// @ui {"widget":"group_end"}
// @input float laserSpeed = 1
// @input float speed = 0.1
// @input float minCollisionDistance = 50
// @input SceneObject startScreen
// @ui {"widget":"group_start", "label":"Explosion"}
// @input SceneObject[] explosionObject
// @input Asset.Texture[] explosion
// @input Component.Image gameOverExplosion
// @ui {"widget":"group_end"}
// @ui {"widget":"group_start", "label":"Audio"}
// @input Component.AudioComponent menu
// @input Component.AudioComponent laserShot
// @input Component.AudioComponent collision
// @input Component.AudioComponent gameOver
// @ui {"widget":"group_end"}
// @input bool advanced = false;
// @input Component.Text highScoreText {"showIf": "advanced"}
// @input Component.Text highScore {"showIf": "advanced"}
// @input Component.Text currentScore {"showIf": "advanced"}
// @input Component.Text hit {"showIf": "advanced"}
// @input SceneObject space {"showIf": "advanced"}
// @input  Component.Text halfSpaceText
// @input SceneObject halfSpace {"showIf": "advanced"}
// @input SceneObject halfSpaceToggleButton {"showIf": "advanced"}
// @input SceneObject frontAsteroids {"showIf": "advanced"}
// @input Component.Text spaceText {"showIf": "advanced"}
// @input SceneObject spaceToggleButton {"showIf": "advanced"}
// @input Component.Text hintText {"showIf": "advanced"}

var currentScore = 0;
var highScore = 0;

// Define the key which the persistent storage system will use to save the data to
const highScoreKey = "hs_template_high_score";

// Get the data associated with the key from the persistent storage system
var persistentStorageSystem = global.persistentStorageSystem.store;
highScore = persistentStorageSystem.getFloat(highScoreKey) || 0;

// Update the high score label
updateHighScoreText();

global.behaviorSystem.addCustomTriggerResponse("enableHalfSpace", enableHalfSpace);
global.behaviorSystem.addCustomTriggerResponse("enableFullSpace", enableFullSpace);

var gameStarted = false;
var backCam = false;
var asteroidToSpawn = 0;
var spawnTime = 0;
var currentAsteroid;
var currentLaser;
var laserArray = [];
var laserPos = [];
var newLaserPos = [];
var laserSpeedVector = new vec3(0,0,-100);
var defaultLaserRotation = quat.fromEulerAngles(90,0,0);
var randomSpawnX;
var randomSpawnY;
var randomSpawnZ;
var randomSize;
var camPos = script.cam.getTransform().getWorldPosition();
var asteroidArray = [];
var currentAsteroidPos = [];
var newAsteroidPos = [];
var asteroidDistance = [];
var halfSpaceEnabled = false;
var asteroidSpawnInterval = script.spawnInterval;
var asteroidSpeed = script.speed;
var explosionCount = -1;
var explosionArray = [script.explosionObject[0], script.explosionObject[1],
                      script.explosionObject[2], script.explosionObject[3],
                      script.explosionObject[4]];
var currentExplosion;
var explode = [script.explosion[0].control, script.explosion[1].control, 
               script.explosion[2].control, script.explosion[3].control,
               script.explosion[4].control];
global.gameOver = true;

var event = script.createEvent("TurnOnEvent");
event.bind(function (eventData)
{
    script.halfSpace.enabled = false;
    script.hit.enabled = false;
    script.spaceText.enabled = true;
    script.spaceToggleButton.enabled = true;
    script.halfSpaceToggleButton.enabled = true;
    script.halfSpaceText.enabled = true;
    script.gameOverExplosion.mainPass.baseTex = script.explosion[0];
    global.touchSystem.touchBlocking = true;
    script.gameOverExplosion.enabled = false;
    script.startScreen.enabled = true;
    script.highScore.text = "High Score"
    script.highScoreText.enabled = true;
    script.currentScore.enabled = false;
    script.menu.play(-1);
});

var event = script.createEvent("UpdateEvent");
event.bind(function (eventData)
{
    if (!global.gameOver)
    {
        spawnTime += getDeltaTime();
        if (spawnTime >= asteroidSpawnInterval)
        {
            spawnAsteroid();
            spawnTime = 0;
            
            if (asteroidSpawnInterval > 1)
            {
                asteroidSpawnInterval -= 0.5;
            }        
        }
        
        moveLasers();
        moveAsteroids(); 
        checkAsteroidDistance();
        checkLaserAsteroidCollision();        
    }

});

var event = script.createEvent("CameraFrontEvent");
event.bind(function (eventData)
{
    backCam = false;
    gameOver();
    script.space.enabled = false;
    script.halfSpace.enabled = false;
    script.startScreen.enabled = false;  
    script.frontAsteroids.enabled = true;
    script.spaceToggleButton.enabled = false;
    script.halfSpaceText.enabled = false;
    script.halfSpaceToggleButton.enabled = false;
    script.spaceText.enabled = false;
    script.hintText.enabled = true;
    script.hintText.text = "Flip Camera to start Playing!"

    var delayedEvent = script.createEvent("DelayedCallbackEvent");
    delayedEvent.bind(function(eventData)
    {
        script.hintText.enabled = false;
    });
    delayedEvent.reset(2);
});

var event = script.createEvent("CameraBackEvent");
event.bind(function (eventData)
{
    script.space.enabled = true;
    backCam = true;
    gameStarted = false;
    gameOver();
    script.startScreen.enabled = true;
    script.frontAsteroids.enabled = false;
    script.spaceToggleButton.enabled = true;
    script.halfSpaceText.enabled = true;
    script.halfSpaceToggleButton.enabled = true;
    script.spaceText.enabled = true;
    script.hintText.enabled = false;
});

var touchEvent = script.createEvent("TouchStartEvent");
touchEvent.bind(function(eventData)
{
    if (!global.gameOver)
    {
       spawnLaser(eventData.getTouchPosition());
    }
    else if (global.start && global.gameOver)
    {
        gameStarted = true;
        script.spaceText.enabled = false;
        script.spaceToggleButton.enabled = false;  
        script.halfSpaceText.enabled = false;
        script.halfSpaceToggleButton.enabled = false;
        script.startScreen.enabled = false;
        global.gameOver = false;
        script.highScore.text = "Score";
        script.highScoreText.enabled = false;
        script.currentScore.enabled = true;
        if (script.menu.isPlaying())
        {
            script.menu.stop(true);
        }
        spawnAsteroid();
        global.start = false;
        script.hintText.enabled = true;
        script.hintText.text = "Rotate Phone to Find Asteroids!";
        
        var delayedEvent = script.createEvent("DelayedCallbackEvent");
        delayedEvent.bind(function(eventData)
        {
            script.hintText.text = "Tap to Fire Lasers!";
        });
        delayedEvent.reset(2);  
        
        var delayedEvent1 = script.createEvent("DelayedCallbackEvent");
        delayedEvent1.bind(function(eventData)
        {
            script.hintText.enabled = false;
        });
        delayedEvent1.reset(4); 
    }
});

function enableHalfSpace()
{
    script.halfSpaceText.text = "180 Degrees";
    script.halfSpace.enabled = true;
    halfSpaceEnabled = true;
}

function enableFullSpace()
{
    script.halfSpaceText.text = "360 Degrees";
    script.halfSpace.enabled = false;
    halfSpaceEnabled = false;
}

function spawnLaser(screenPos)
{
    var camTransform = script.cam.getTransform();
    
    var position = script.cam.screenSpaceToWorldSpace(screenPos, 50)// increased depth here 
    
    // try two options here - uncomment the one you need
    // option one - look at camera direction - shoot from screen
    //var direction = camTransform.forward;
    // option two - look at camera position - shoot from point
    var direction = camTransform.getWorldPosition().sub(position);
    //pick one
     
    var rotation = quat.lookAt(direction, vec3.up());
    
    var matrix = mat4.fromRotation(rotation);
    
    currentLaser = script.laser.instantiate(script.parentObject);
    currentLaser.getTransform().setWorldPosition(position);
    currentLaser.getTransform().setWorldRotation(rotation);
    //laserArray.push(currentLaser);
    var curLaserSpeedVector = matrix.multiplyDirection(laserSpeedVector); //made fix here
    // instead of storing sceneObjects in array i store an object, that has references to sceneObject 
    //and information about speed
    laserArray.push({ 
        sceneObject : currentLaser,
        speed : curLaserSpeedVector
    })
    script.laserShot.play(1);
}


function moveLasers()
{
    if (laserArray.length > 0 && laserArray != null)
    {           
        for (var i = 0; i < laserArray.length; i++)
        {
            //fixed two lines of code here to work woth laser objects           
            laserPos.splice(i, 0, laserArray[i].sceneObject.getTransform().getWorldPosition());
            newLaserPos.splice(i, 0, laserPos[i].add(laserArray[i].speed.uniformScale(getDeltaTime())));
            laserArray[i].sceneObject.getTransform().setWorldPosition(newLaserPos[i]);
            
            var distanceFromCam = laserPos[i].distance(camPos);
            if (distanceFromCam > 500)
            {
                destroyLaser(i);
            }
        }
    }
}

function checkLaserAsteroidCollision()
{
    for (var i = 0; i < laserArray.length; i++)
    {
        for (var j = 0; j < asteroidArray.length; j++)
        {
            if (laserPos[i].distance(newAsteroidPos[j]) < script.minCollisionDistance && !global.gameOver)
            {
                createExplosion(newAsteroidPos[j]);
                destroyAsteroid(j);
                destroyLaser(i);   
                script.collision.play(1);
                incrementScore();
            }
        }
    }
}

function createExplosion(explosionPosition)
{    
    explosionCount++;
    
    if (explosionCount >= explosionArray.length)
    {
        explosionCount = 0;
    }
    
    explosionArray[explosionCount].getTransform().setWorldPosition(explosionPosition);
    explode[explosionCount].play(1, 0);
}


function destroyLaser(laserIndex)
{
    laserArray[laserIndex].sceneObject.destroy();
    laserArray.splice(laserIndex, 1);
    laserPos.splice(laserIndex, 1);
    newLaserPos.splice(laserIndex, 1);
}

function spawnAsteroid()
{
    asteroidArray.push(script.asteroid[asteroidToSpawn].instantiate(script.parentObject));
    asteroidToSpawn++;
    if (asteroidToSpawn > 5)
    {
        asteroidToSpawn = 0;
    }
    currentAsteroid = asteroidArray[asteroidArray.length - 1]; 
    
    if (!halfSpaceEnabled)
    {
        randomSpawnX = Math.floor(Math.random() * script.maxDistance) + script.minDistance;
        randomSpawnX *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
        randomSpawnY = Math.floor(Math.random() * script.maxHeight);
        randomSpawnY *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
        randomSpawnZ = Math.floor(Math.random() * script.maxDistance) + script.minDistance;
        randomSpawnZ *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
        randomSize = Math.floor(Math.random() * script.maxSize) + script.minSize;
    }
    else
    {
        randomSpawnX = Math.floor(Math.random() * script.maxDistance) + script.minDistance;
        randomSpawnX *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
        randomSpawnY = Math.floor(Math.random() * (script.maxHeight * 2));
        randomSpawnY *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
        randomSpawnZ = Math.floor(Math.random() * script.maxDistance) + script.minDistance;
        randomSpawnZ *= -1;
        randomSize = Math.floor(Math.random() * script.maxSize) + script.minSize;
    }
    

    
    currentAsteroid.getTransform().setLocalPosition(new vec3(
    randomSpawnX, randomSpawnY, randomSpawnZ));
    
    currentAsteroid.getTransform().setLocalScale(new vec3(
    randomSize, randomSize, randomSize));
}

function moveAsteroids()
{
    if (asteroidArray.length > 0 && asteroidArray != null)
    {    
        for (var i = 0; i < asteroidArray.length; i++)
        {
            currentAsteroidPos.splice(i, 0, asteroidArray[i].getTransform().getLocalPosition());
            newAsteroidPos.splice(i, 0, vec3.lerp(currentAsteroidPos[i], camPos, asteroidSpeed));
            asteroidArray[i].getTransform().setLocalPosition(newAsteroidPos[i]);
        }
    }
}

function checkAsteroidDistance()
{
    for (var i = 0; i < asteroidArray.length; i++)
    {
        asteroidDistance.splice(i, 0, currentAsteroidPos[i].distance(camPos));
        
        if (asteroidDistance[i] <= script.minGameOverDistance)
        {           
            script.gameOverExplosion.enabled = true;
            explode[0].play(1, 0);
            explode[0].setOnFinish(disableEndingExplosion);
            destroyAsteroid(i);
            gameOver();
            script.gameOver.play(1);
        }
    }
}

function disableEndingExplosion()
{
    script.gameOverExplosion.enabled = false;
}


function destroyAsteroid(asteroidIndex)
{
    asteroidArray[asteroidIndex].destroy();
    asteroidArray.splice(asteroidIndex, 1);
    currentAsteroidPos.splice(asteroidIndex, 1);
    newAsteroidPos.splice(asteroidIndex, 1);
}

function gameOver()
{
    script.spaceText.enabled = true;
    script.spaceToggleButton.enabled = true;
    script.halfSpaceText.enabled = true;
    script.halfSpaceToggleButton.enabled = true;
    script.highScore.text = "High Score";
    script.highScoreText.enabled = true;
    script.currentScore.enabled = false;
    asteroidSpawnInterval = script.spawnInterval;
    asteroidSpeed = script.speed;
    destroyEverything();
    setHighScore();
    script.startScreen.enabled = true;
    global.gameOver = true;
    endGame();
    
    if (!script.menu.isPlaying())
    {
        script.menu.play(-1);
    }
    
    if (backCam && gameStarted)
    {
        gameStarted = false;
        script.hit.enabled = true;

        var delayedEvent = script.createEvent("DelayedCallbackEvent");
        delayedEvent.bind(function(eventData)
        {
            global.play = false;
            script.hit.enabled = false;
        });
        delayedEvent.reset(2);
    }
    else if (backCam)
    {
        global.play = false;
    }
    

}

function destroyEverything()
{
    for (var i = 0; i < asteroidArray.length; i++)
    {
        asteroidArray[i].destroy();     
    }
    for (var i = 0; i < laserArray.length; i++)
    {
        laserArray[i].sceneObject.destroy();
    }

    asteroidArray = [];
    currentAsteroidPos = [];
    newAsteroidPos = [];  
    laserArray = [];
    laserPos = [];
    newLaserPos = [];
}

function updateScoreText() {
    script.currentScore.text = currentScore.toString();
}

function updateHighScoreText() {
    script.highScoreText.text = highScore.toString();
}

function incrementScore() {
    currentScore++;
    updateScoreText();
}

function setHighScore() {
    if( currentScore > highScore ) {
        highScore = currentScore;

        // Set the data associated with the key from the persistent storage system
        persistentStorageSystem.putFloat(highScoreKey, currentScore);

        // Update the high score text since its been updated
        updateHighScoreText();
    }
}

function resetGame() {
    currentScore = 0;
    updateScoreText();
}

function endGame() {
    setHighScore();
    resetGame();
}

function spaceOn()
{
    script.space.enabled = true;
    script.spaceText.text = "Space On";
}

function spaceOff()
{
    script.space.enabled = false;
    script.spaceText.text = "Space Off";
}