// -----JS CODE-----

print("Welcome to the Hand Drawing template! To add your own effects, replace the Post effects under the 'Effects' camera. If you want to make the effects disappear when you move your hand instead of appear, invert the colors of the 'Brush' and 'Background' (Change white to black, and black to white). If you have any questions, message Ben @k-nuts91 on Snapchat!");