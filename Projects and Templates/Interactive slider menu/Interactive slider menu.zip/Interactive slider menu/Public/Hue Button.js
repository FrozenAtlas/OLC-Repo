var event = script.createEvent("TouchStartEvent");
event.bind(function(eventData)
{
    
});

var event = script.createEvent("TouchEndEvent");
event.bind(function(eventData)
{
    
});