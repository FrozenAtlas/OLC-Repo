Plazy#8996

Here you guys have an RGB Template. You can play around with the color, opacity and size of the billboards and materials. Let me know if you have any problems!