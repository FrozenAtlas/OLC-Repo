// -----JS CODE-----
// Made By Ben Knutson

// @input bool segmentation = false;
// @input float tracersIntensity = 0.85 {"widget":"slider", "min":0.0, "max":1.0, "step":0.01}
// @ui {"widget":"separator"}

// @ui {"widget":"group_start", "label":"Advanced"}
// @input Component.Image tracerInput
// @input Component.Camera cam
// @input Asset.Texture segmentationTexture
// @ui {"widget":"group_end"}

if (script.segmentation)
{
    script.cam.maskTexture = script.segmentationTexture;
}

script.tracerInput.mainPass.baseColor = new vec4(1,1,1,script.tracersIntensity);